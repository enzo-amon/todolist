/********* Imports *********/
import { createTheme } from "@mui/material";

/********* Theme *********/
export const theme = createTheme({});
