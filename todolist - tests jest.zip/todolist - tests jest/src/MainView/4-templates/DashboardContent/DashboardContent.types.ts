//********** Props **********//
export interface DashboardContentProps {
  selectedItemId?: string;
}
