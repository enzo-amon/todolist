export const DRAWER_WIDTH: number = 240;
